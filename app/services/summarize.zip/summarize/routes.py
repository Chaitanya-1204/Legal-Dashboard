# app/services/summarize/routes.py
from __future__ import annotations
from flask import Blueprint, request, jsonify, abort, render_template
from app import db
from .summarizer import summarize_text

summary_bp = Blueprint(
    "summary",
    __name__,
    template_folder="templates",
    static_folder="static",
)

def _html_from_doc(d: dict) -> str:
    if not d:
        return ""
    for k in ("content_ner_html","ner_html","content_html","html","raw_html","body_html","content"):
        v = d.get(k)
        if isinstance(v, str) and v.strip():
            return v
    return ""

def _fetch_html(doc_type: str, doc_id: int) -> str:
    coll_name = {
        "acts": "acts",
        "judgments": "judgments",
        "tribunals": "tribunals",
        "districtcourt": "districtcourt",
    }.get(doc_type.lower())
    if not coll_name:
        abort(400, "Unknown doc_type")
    doc = db[coll_name].find_one({"doc_id": int(doc_id)}, {"_id": 0})
    if not doc:
        abort(404, "Document not found")
    return _html_from_doc(doc)

@summary_bp.route("/api/summarize", methods=["POST"])
def api_summarize():
    try:
        data = request.get_json(force=True, silent=True) or {}
        model = data.get("model") or "facebook/bart-large-cnn"
        target_tokens = int(data.get("target_tokens") or 200)
        min_tokens = int(data.get("min_tokens") or 70)
        is_html = bool(data.get("is_html", True))

        text = ""
        if data.get("html"):
            text = data["html"]; is_html = True
        elif data.get("text"):
            text = data["text"]; is_html = False
        elif data.get("doc_type") and data.get("doc_id") is not None:
            text = _fetch_html(str(data["doc_type"]), int(data["doc_id"])); is_html = True
        else:
            abort(400, "Provide either (html/text) or (doc_type + doc_id).")

        result = summarize_text(
            text,
            model_name=model,
            target_tokens=target_tokens,
            min_tokens=min_tokens,
            is_html=is_html,
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@summary_bp.route("/view/<doc_type>/<int:doc_id>", methods=["GET"])
def view_summary(doc_type: str, doc_id: int):
    model = request.args.get("model") or "facebook/bart-large-cnn"
    target_tokens = int(request.args.get("target_tokens") or 200)
    min_tokens = int(request.args.get("min_tokens") or 70)

    html = _fetch_html(doc_type, doc_id)
    result = summarize_text(
        html,
        model_name=model,
        target_tokens=target_tokens,
        min_tokens=min_tokens,
        is_html=True,
    )
    return render_template(
        "summarize/summary_view.html",
        summary=result["summary"],
        meta=result.get("meta", {}),
        model=model,
        target_tokens=target_tokens,
        min_tokens=min_tokens,
        doc_type=doc_type,
        doc_id=doc_id,
    )

@summary_bp.route("/view/html", methods=["POST"])
def view_from_html():
    html = request.form.get("html")
    if not html and request.is_json:
        html = (request.get_json(silent=True) or {}).get("html")
    if not html:
        abort(400, "Missing 'html'")

    model = request.form.get("model") or "facebook/bart-large-cnn"
    target_tokens = int(request.form.get("target_tokens") or 200)
    min_tokens = int(request.form.get("min_tokens") or 70)
    doc_type = request.form.get("doc_type") or None
    doc_id = request.form.get("doc_id") or None
    if doc_id:
        try: doc_id = int(doc_id)
        except Exception: doc_id = None

    result = summarize_text(
        html,
        model_name=model,
        target_tokens=target_tokens,
        min_tokens=min_tokens,
        is_html=True,
    )
    return render_template(
        "summarize/summary_view.html",
        summary=result["summary"],
        meta=result.get("meta", {}),
        model=model,
        target_tokens=target_tokens,
        min_tokens=min_tokens,
        doc_type=doc_type,
        doc_id=doc_id,
    )
