# app/services/summarize/__init__.py
from .routes import summary_bp  # re-export the blueprint

__all__ = ["summary_bp"]

def register(app):
    """Optional helper to register the blueprint."""
    app.register_blueprint(summary_bp, url_prefix="/summary")
