# app/services/summarize/summarizer.py
from __future__ import annotations
from typing import Dict, Any, List, Optional
import os, re, json, time
import requests

try:
    from bs4 import BeautifulSoup
    _HAS_BS4 = True
except Exception:
    _HAS_BS4 = False


# ----------------- text utils -----------------

def _strip_html(html: str) -> str:
    if not html:
        return ""
    if _HAS_BS4:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup(["script", "style"]):
            tag.decompose()
        text = soup.get_text(" ", strip=True)
        return re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"<(script|style)[\\s\\S]*?</\\1>", " ", html, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\\s+", " ", text).strip()


def _chunk_by_chars(text: str, chunk_chars: int, overlap_chars: int) -> List[str]:
    text = (text or "").strip()
    if not text:
        return []
    parts: List[str] = []
    step = max(1, chunk_chars - overlap_chars)
    for i in range(0, len(text), step):
        parts.append(text[i:i + chunk_chars])
        if i + chunk_chars >= len(text):
            break
    return parts


# ----------------- HF Inference API -----------------

_HF_URL = "https://api-inference.huggingface.co/models/{model}"

def _hf_headers() -> Dict[str, str]:
    token = os.getenv("HF_INFERENCE_TOKEN") or os.getenv("HUGGINGFACEHUB_API_TOKEN")
    if not token:
        raise RuntimeError(
            "HF_INFERENCE_TOKEN not set. Get a token from https://huggingface.co/settings/tokens "
            "and set it in your environment."
        )
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

def _hf_summarize_once(
    text: str,
    model: str,
    max_new: int,
    min_new: int,
    timeout: int = 120,
    max_retries: int = 6,
) -> str:
    """
    Call HF Inference API once for a single piece of text.
    Retries politely on 429/503, honors estimated_time/Retry-After when present.
    """
    url = _HF_URL.format(model=model)
    headers = _hf_headers()

    # Use both old-style (min/max_length) and new-style (min/max_new_tokens) for broad compat.
    params = {
        "max_new_tokens": int(max_new),
        "min_new_tokens": int(min_new),
        "do_sample": False,
    }
    # Conservative cap if a backend insists on max_length
    params["max_length"] = max(32, int(max_new) + 32)
    params["min_length"] = max(8, int(min_new))

    payload = {
        "inputs": text,
        "parameters": params,
        "options": {"wait_for_model": True, "use_cache": True},
    }

    last_err = None
    for attempt in range(max_retries):
        try:
            resp = requests.post(url, headers=headers, data=json.dumps(payload), timeout=timeout)
            # Success
            if resp.status_code == 200:
                data = resp.json()
                # Typical summarization response
                if isinstance(data, list) and data and isinstance(data[0], dict):
                    if "summary_text" in data[0]:
                        return (data[0]["summary_text"] or "").strip()
                    if "generated_text" in data[0]:
                        return (data[0]["generated_text"] or "").strip()
                if isinstance(data, dict) and "generated_text" in data:
                    return (data["generated_text"] or "").strip()
                # Fallback: stringify
                return (str(data) or "").strip()

            # Model loading or rate-limited
            wait = None
            try:
                j = resp.json()
            except Exception:
                j = {}
            if resp.status_code in (429, 503):
                # Respect estimate or Retry-After
                wait = j.get("estimated_time")
                if not wait:
                    ra = resp.headers.get("Retry-After")
                    wait = float(ra) if ra else None
            if wait is None:
                wait = 5 + attempt * 2  # gentle backoff
            time.sleep(min(max(wait, 2), 30))
            last_err = (resp.status_code, j if j else resp.text)
            continue

        except requests.RequestException as e:
            last_err = e
            time.sleep(2 + attempt * 1.5)

    raise RuntimeError(f"HF API failed after {max_retries} tries: {last_err}")

# ----------------- public API -----------------

def summarize_text(
    text: str,
    *,
    model_name: str = "facebook/bart-large-cnn",
    target_tokens: int = 200,
    min_tokens: int = 70,
    chunk_chars: int = 4000,
    overlap_chars: int = 600,
    is_html: bool = True,
) -> Dict[str, Any]:
    """
    Summarize LONG text/HTML using Hugging Face Inference API with simple map->reduce chunking.
    Returns: {'summary': '...', 'meta': {...}}
    """
    if not isinstance(text, str) or not text.strip():
        return {"summary": "", "meta": {"model": model_name, "chunks": 0, "backend": "hf_api"}}

    raw = _strip_html(text) if is_html else re.sub(r"\s+", " ", text).strip()
    if not raw:
        return {"summary": "", "meta": {"model": model_name, "chunks": 0, "backend": "hf_api"}}

    # 1) Chunk (char-based so we don't need any local tokenizer)
    parts = _chunk_by_chars(raw, chunk_chars=chunk_chars, overlap_chars=overlap_chars)
    if not parts:
        parts = [raw]

    # 2) Map: summarize each chunk via API
    per_chunk_tokens = max(60, min(target_tokens, 250))
    per_chunk_min = min(min_tokens, per_chunk_tokens // 2)
    interim: List[str] = []
    for ch in parts:
        try:
            s = _hf_summarize_once(ch, model=model_name, max_new=per_chunk_tokens, min_new=per_chunk_min)
        except Exception:
            # fallback: truncate chunk into interim if API fails for a window
            s = ch[:1500]
        interim.append(s)

    # 3) Reduce
    merged = " ".join(interim)
    final = _hf_summarize_once(merged, model=model_name, max_new=target_tokens, min_new=min_tokens)

    return {
        "summary": final.strip(),
        "meta": {
            "model": model_name,
            "chunks": len(parts),
            "target_tokens": target_tokens,
            "min_tokens": min_tokens,
            "backend": "hf_api",
        },
    }
